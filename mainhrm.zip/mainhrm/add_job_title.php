<!DOCTYPE html>
<html>

<body>

<form action="add_job_title.php" method="POST">
jtitle<input type="text" name="job_title"><br>
jobdes<input type="text" name="job_des"><br>
jpeeci<input type="text" name="job_speci"><br>
note<input type="text" name="note"><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$job_title=$_POST['job_title'];
$job_des=$_POST['job_des'];
$job_speci=$_POST['job_speci'];
$note=$_POST['note'];
  $query = "INSERT INTO add_jobs(job_title,job_des,job_speci,note)
  VALUES('$job_title','$job_des','$job_speci','$note')";
 if(mysqli_query($con,$query))
 {
     echo"details inserted sucessfully";

 }
 else
 {
     echo "failed to insert";
}
}
?>