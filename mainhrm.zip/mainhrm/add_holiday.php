<!DOCTYPE html>
<html>

<body>

<form action="add_holiday.php" method="POST">
namae<input type="text" name="name"><br>
date<input type="date" name="date"><br>
anual<input type="text" name="repeat_anual"><br>
type<input type="text" name="type"><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$name=$_POST['name'];
$date=$_POST['date'];
$repeat_anual=$_POST['repeat_anual'];
$type=$_POST['type'];

  $query = "INSERT INTO add_holiday(name,date,repeat_anual,type)
  VALUES('$name','$date','$repeat_anual','$type')";
 if(mysqli_query($con,$query))
 {
     echo"details inserted sucessfully";

 }
 else
 {
     echo "failed to insert";
}
}
?>