<?php
require('dbconn.php');
mysqli_select_db($con,"hrm");
//$sql =mysqli_query($con,"SELECT apply_leave.id as lid,add_employees.first_name,add_employees.id,
//apply_leave.leave_type,apply_leave.lev_comments from apply_leave join add_employees on apply_leave.id=add_employees.id order by lid dec");
$sql = mysqli_query($con,"SELECT id, first_name from add_employees inner join apply_leave on add_employees.id=apply_leave.id");


while($row = mysqli_fetch_row($sql))
{

?>
<html>
<body>
	

<tr>
	<td><?php echo $row["first_name"]?></td>
	<td><?php echo $row["id"]?></td>
	<td><?php echo $row["leave_type"]?></td>
	<td><?php echo $row["lev_comments"]?></td>
	
</tr>

<?php
}


  ?>

</body>
</html>

