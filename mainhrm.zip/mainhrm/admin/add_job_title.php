<!DOCTYPE html>
<html>

<body>

<form action="add_job_title.php" method="POST">


<?php
require('dbconn.php');
$sql = "SELECT * FROM add_jobs";
$result = mysqli_query($con,$sql);

echo "jtitle<select name='job_title'>";
while ($row = mysqli_fetch_array($result)) {
    echo "<option value='" . $row['job_title'] ."'>" . $row['job_title'] ."</option>";
}
echo "</select>";
?>



<?php
require('dbconn.php');
$sql = "SELECT * FROM add_jobs";
$result = mysqli_query($con,$sql);
echo "jspeci<select name='job_speci'>";
while ($row = mysqli_fetch_array($result)) {
    echo "<option value='" . $row['job_speci'] ."'>" . $row['job_speci'] ."</option>";
}
echo "</select>";
?>



<?php
require('dbconn.php');
$sql = "SELECT * FROM add_employment_status";
$result = mysqli_query($con,$sql);
echo "empstatus<select name='employment_status'>";
while ($row = mysqli_fetch_array($result)) {
    echo "<option value='" . $row['employment_status'] ."'>" . $row['employment_status'] ."</option>";
}
echo "</select>";
?>


<?php
require('dbconn.php');
$sql = "SELECT * FROM add_job_category";
$result = mysqli_query($con,$sql);
echo "jcategory<select name='job_category'>";
while ($row = mysqli_fetch_array($result)) {
    echo "<option value='" . $row['job_category'] ."'>" . $row['job_category'] ."</option>";
}
echo "</select>";
?>


<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$job_title=$_POST['job_title'];
$job_speci=$_POST['job_speci'];
$employment_status=$_POST['employment_status'];
$job_category=$_POST['job_category'];
  $query = "INSERT INTO add_jobs(job_title,job_speci,employment_status,job_category)
  VALUES('$job_title','$job_speci','$employment_status','$job_category')";
 if(mysqli_query($con,$query))
 {
     echo"details inserted sucessfully";

 }
 else
 {
     echo "failed to insert";
}
}
?>