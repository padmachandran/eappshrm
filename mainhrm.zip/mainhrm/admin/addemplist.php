<?php
require('dbconn.php');

session_start();
$sq="SELECT * from add_employees";
$res=mysqli_query($con,$sq);
?>
<table border=  1px solid>
<thead>
        <tr>
          <th>f_name</th>
          <th>m_name</th>
          <th>l_name</th>
        </tr>
</thead>


<?php
     while ($row = mysqli_fetch_array($res)){
        $first_name = $row['first_name'];
        $middle_name = $row['middle_name'];
        $last_name = $row['last_name'];
?>
<tr >
<td><a href="dashboard.php"><?php echo $first_name;?></a></td>
<td><a href="addpersonaldetails.php"><?php echo $middle_name;?></a></td>
<td><a href="addpersonaldetails.php"><?php echo $last_name;?></a></td>
</tr>


</table>
<?php }
?>