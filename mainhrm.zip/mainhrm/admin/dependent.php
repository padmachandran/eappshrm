<!DOCTYPE html>
<html>

<body>

<form action="dependent.php" method="POST">
name<input type="text" name="name" ><br>
rel<input type="text" name="relationship"><br>
dob<input type="date" name="dob"><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$name=$_POST['name'];
$relationship=$_POST['relationship'];
$dob=$_POST['dob'];

  $query = "INSERT INTO dependents(name,relationship,dob)
  VALUES('$name','$relationship','$dob')";
 if(mysqli_query($con,$query))
 {
     echo"details inserted successfully";

 }
 else
 {
     echo "failed to insert";
}
}
?>