<?php
$con= new mysqli("localhost","root","","hrm");
if($con->connect_error)
{
echo $con->connect_error;
die("sorry error");

}
?>