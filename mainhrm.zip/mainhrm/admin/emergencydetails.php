<!DOCTYPE html>
<html>

<body>

<form action="emergencydetails.php" method="POST">
name<input type="text" name="name" ><br>
rel<input type="text" name="relationship"><br>
hom_tel<input type="text" name="home_tel"><br>
mob<input type="text" name="mobile"  ><br>
w_tel<input type="text" name="work_tel" ><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$name=$_POST['name'];
$relationship=$_POST['relationship'];
$home_tel=$_POST['home_tel'];
$mobile=$_POST['mobile'];
$work_tel=$_POST['work_tel'];
  $query = "INSERT INTO emergency_details(name,relationship,home_tel,mobile,work_tel)
  VALUES('$name','$relationship','$home_tel','$mobile','$work_tel')";
 if(mysqli_query($con,$query))
 {
     echo"details inserted successfully";

 }
 else
 {
     echo "failed to insert";
}
}
?>