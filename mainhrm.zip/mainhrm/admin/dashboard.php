<?php
require('dbconn.php');
session_start();

echo $_SESSION['emp_id']; 
?>

<div class="na" >
<ul>
<li><a href="personaldetails.php">personal details</li>
<li><a href="add_job_title.php">job</li>
<li><a href="contactdetails.php">contact details</li>
<li><a href="emergencydetails.php">emergency contacts</li>
<li><a href="dependent.php">dependents</li>
<li><a href="logout.php">logout</li>
</ul>
</div>
