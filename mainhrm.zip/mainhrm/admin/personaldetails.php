<!DOCTYPE html>
<html>
<head>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script>
$(document).ready(function(){
    $('input').prop("readonly",true).css('background-color','silver');
    //$("input[type='radio']").prop("readonly",false).css('background-color','silver');
    //$(':radio:not(:checked)').prop("readonly",false).css('background-color','silver');
    //$("input[type='radio']").click(function(){
    //$(':radio').prop("readonly",false).css('background-color','silver');
    //$("#edit").click(function(){
        //$(':radio').prop("readonly",false).css('background-color','white');
//});
  $("#edit").click(function () {
    $('input').prop("readonly",false).css('background-color','white');
  });

 });

</script>
</head>
<body>
<form action="personaldetails.php" method="POST">

<?php 
require('dbconn.php');
session_start();
echo $_SESSION['username']; 
$qu= "SELECT first_name,middle_name,last_name FROM `add_employees` WHERE `username` = '".$_SESSION['username']."' ";
$res=mysqli_query($con,$qu);
     while ($row = mysqli_fetch_array($res)){
         $first_name = $row['first_name'];
         $middle_name = $row['middle_name'];
         $last_name = $row['last_name'];
         ?>
         
        fname<input type="text" id="fname" value="<?php echo $first_name;?>">
        mname<input type="text" id="mname" value="<?php echo $middle_name;?>">
        lname<input type="text" id="lname" value="<?php echo $last_name;?>">
        <?php
    }
    ?>

dob<input type="date" name="dob" id="dob" ><br>
gender<input type="radio" name="gender" id="gen" value="female"> Female
<input type="radio" name="gender" id="gen" value="male"> male<br>
m_status<input type="text" id="mstatus" name="marital_status"><br>
nation<input type="text" id="nation" name="nationality"><br>
<input type="submit" name="submit" id="submit">
<button type="button" name="edit" id="edit">edit</button>

</form>
</body>
</html>

<?php
require('dbconn.php');
if(isset($_POST['submit']))
{
//$first_name=$_POST['first_name'];
//$middle_name=$_POST['middle_name'];
//$last_name=$_POST['last_name'];
$dob=$_POST['dob'];
$gender=$_POST['gender'];
$marital_status=$_POST['marital_status'];
$nationality=$_POST['nationality'];

  //$query = "INSERT INTO personal_details(first_name,middle_name,last_name,dob,gender,marital_status,nationality)VALUES('$first_name','$middle_name','$last_name','$dob','$gender','$marital_status','$nationality')";
  $query = "UPDATE personal_details SET first_name='$first_name',middle_name='$middle_name',last_name='$last_name',dob='$dob',gender='$gender',
  marital_status='$marital_status',nationality='$nationality' WHERE `username` = '".$_SESSION['username']."'";
  if(mysqli_query($con,$query))
 {
     echo"details inserted successfully";

 }
 else
 {
     echo "failed to insert";
}
}
?>
