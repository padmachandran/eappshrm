<?PHP

session_start();
session_destroy();
echo"logout successfull";
header('location:index.php');

?>