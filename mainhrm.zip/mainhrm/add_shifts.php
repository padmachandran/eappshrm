<!DOCTYPE html>
<html>

<body>

<form action="add_shifts.php" method="POST">
name<input type="text" name="shift_name"><br>
time_from<input type="text" name="time_from"><br>
time_to<input type="text" name="time_to"><br>
duration<input type="text" name="duration"><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$shift_name=$_POST['shift_name'];
$time_from=$_POST['time_from'];
$time_to=$_POST['time_to'];
$duration=$_POST['duration'];

$query = "INSERT INTO add_shifts(shift_name,time_from,time_to,duration)
  VALUES('$shift_name','$time_from','$time_to','$duration')";
 if(mysqli_query($con,$query))
 {
     echo"details inserted sucessfully";

 }
 else
 {
     echo "failed to insert";
}
}
?>