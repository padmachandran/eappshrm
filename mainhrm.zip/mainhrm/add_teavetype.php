<!DOCTYPE html>
<html>

<body>

<form action="add_.php" method="POST">
type<input type="text" name="leave_type"><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$job_category=$_POST['job_category'];

$query = "INSERT INTO add_job_category(job_category)
  VALUES('$job_category')";
 if(mysqli_query($con,$query))
 {
     echo"details inserted sucessfully";

 }
 else
 {
     echo "failed to insert";
}
}
?>