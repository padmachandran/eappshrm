<!DOCTYPE html>
<html>
<head>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script>
$(document).ready(function(){
    $('input').prop("readonly",true).css('background-color','silver');
    //$("input[type='radio']").prop("readonly",false).css('background-color','silver');
    //$(':radio:not(:checked)').prop("readonly",false).css('background-color','silver');
    //$("input[type='radio']").click(function(){
    //$(':radio').prop("readonly",false).css('background-color','silver');
    //$("#edit").click(function(){
        //$(':radio').prop("readonly",false).css('background-color','white');
//});
  $("#edit").click(function () {
    $('input').prop("readonly",false).css('background-color','white');
  });

 });

</script>
</head>
<body>
<form action="personaldetails.php" method="POST">

<?php 
require('dbconn.php');
session_start();
$emp=$_SESSION['emp_id']; 

$qu= "SELECT * FROM `add_employees` WHERE `emp_id` = '".$_SESSION['emp_id']."' ";
$res=mysqli_query($con,$qu);
if(mysqli_num_rows($res)>0)
{
     while ($row = mysqli_fetch_array($res)){
       $emp_id =$row['emp_id'];
         $first_name = $row['first_name'];
         $middle_name = $row['middle_name'];
         $last_name = $row['last_name'];
     }
    }
         ?>
         
         eid<input type="text name="emp_id" id="emp_id" value="<?php echo $emp_id;?>">     
 fname<input type="text" id="fname" name="first_name" value="<?php echo $first_name;?>">
        mname<input type="text" id="mname" name="middle_name" value="<?php echo $middle_name;?>">
        lname<input type="text" id="lname" name="last_name" value="<?php echo $last_name;?>">
       
dob<input type="text" name="dob" id="dob" ><br>
gender<input type="radio" name="gender" id="gen" value="female"> Female
<input type="radio" name="gender" id="gen" value="male"> male<br>
m_status<input type="text" id="mstatus" name="marital_status"><br>
nation<input type="text" id="nation" name="nationality"><br>
<input type="submit" name="submit" id="submit">
<button type="button" name="edit" id="edit">edit</button>

</form>
</body>
</html>

<?php
require('dbconn.php');
if(isset($_POST['submit']))
{
$emp_id=$_POST['emp_id'];
$first_name=$_POST['first_name'];
$middle_name=$_POST['middle_name'];
$last_name=$_POST['last_name'];
$dob=$_POST['dob'];
$gender=$_POST['gender'];
$marital_status=$_POST['marital_status'];
$nationality=$_POST['nationality'];
//if($first_name="" && $middle_name="" && $last_name="" && $dob="" && $gender="" && $marital_status="" && $nationality="")
//{
  
  //echo $query;
  //die();
//}

//else{
  
  //$query = mysqli_query($con,"UPDATE personal_details SET first_name='$first_name',middle_name='$middle_name',last_name='$last_name',dob='$dob',gender='$gender',
  //marital_status='$marital_status',nationality='$nationality' WHERE 'emp_id' = '".$emp."'"); 
 // echo"failed";
//}
  //echo $query;
  //die();
  //$result=mysqli_query($con,$query);
  //echo $result;
  //die();

//}




//$select_query = mysqli_query($con,"SELECT * FROM personal_details WHERE 'emp_id' = '".$emp."'") or die (mysqli_error());
$select_query = mysqli_query($con,"SELECT * FROM personal_details ") or die (mysqli_error());
$result = mysqli_num_rows($select_query);
if($result)
{
    $query = mysqli_query($con,"UPDATE personal_details SET emp_id='$emp_id',first_name='$first_name',middle_name='$middle_name',last_name='$last_name',dob='$dob',gender='$gender',
marital_status='$marital_status',nationality='$nationality' WHERE 'emp_id' = '".$emp."'"); 
}
else{
  echo"failed to update";

}
}
?>