﻿<!DOCTYPE html>
<html>




<body class="login-page">
    <div class="login-box">
        <div class="logo">
            <a href="javascript:void(0);">Admin<b>BSB</b></a>
            <small>Admin BootStrap Based - Material Design</small>
        </div>
        <div class="card">
            <div class="body">
                <form id="sign_in" method="POST">
                    <div class="msg">Sign in to start your session</div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">person</i>
                        </span>
                        <div class="form-line">
                            <input type="text" class="form-control" name="emp_id" placeholder="id" required autofocus>
                        </div>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">lock</i>
                        </span>
                        <div class="form-line">
                            <input type="password" class="form-control" name="password" placeholder="Password" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-8 p-t-5">
                            <input type="checkbox" name="rememberme" id="rememberme" class="filled-in chk-col-pink">
                            <label for="rememberme">Remember Me</label>
                        </div>
                        <div class="col-xs-4">
                            <button class="btn btn-block bg-pink waves-effect" name="submit" type="submit">SIGN IN</button>
                        </div>
                    </div>
                    <div class="row m-t-15 m-b--20">
                        <div class="col-xs-6">
                            <a href="sign-up.php">Register Now!</a>
                        </div>
                        <div class="col-xs-6 align-right">
                            <a href="forgot-password.html">Forgot Password?</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php
require('dbconn.php');
session_start();
//if(isset($_POST['email'])&&isset($_POST['password']))
if(isset($_POST['submit']))
{
$emp_id=$_POST['emp_id'];
$password=$_POST['password'];
$q="select * from add_employees where emp_id='$emp_id' && password='$password'";
$result=mysqli_query($con,$q);
 
    if (mysqli_num_rows($result)==1)
    {
        $row = mysqli_fetch_assoc($result);
        if($row['u_role']=='admin')
        {
            $_SESSION['emp_id']=$emp_id;
            echo "<script> window.location.href = 'admin/admin_dashboard.php';</script>";
        }
        if($row['u_role']=='ess')
        {
            $_SESSION['emp_id']=$emp_id;
            echo "<script> window.location.href = 'user_dashboard.php';</script>";
        }
    }
   
}
?>

