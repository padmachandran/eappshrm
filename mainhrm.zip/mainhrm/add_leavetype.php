<!DOCTYPE html>
<html>

<body>

<form action="add_leavetype.php" method="POST">
type<input type="text" name="leave_type"><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$leave_type=$_POST['leave_type'];

$query = "INSERT INTO add_leave_type(leave_type)
  VALUES('$leave_type')";
 if(mysqli_query($con,$query))
 {
     echo"details inserted sucessfully";

 }
 else
 {
     echo "failed to insert";
}
}
?>