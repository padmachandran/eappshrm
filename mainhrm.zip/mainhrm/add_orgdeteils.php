<!DOCTYPE html>
<html>

<body>

<form action="add_orgdeteils.php" method="POST">
oname<input type="text" name="org_name"><br>
noe<input type="text" name="no_of_emp"><br>
ph<input type="text" name="phone"><br>
addr<input type="text" name="address"><br>
city<input type="text" name="city"><br>
state<input type="text" name="state"><br>
zip<input type="text" name="zip_code"><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$org_name=$_POST['org_name'];
$no_of_emp=$_POST['no_of_emp'];
$phone=$_POST['phone'];
$address=$_POST['address'];
$city=$_POST['city'];
$state=$_POST['state'];
$zip_code=$_POST['zip_code'];

  $query = "INSERT INTO add_org_details(org_name,no_of_emp,phone,address,city,state,zip_code)
  VALUES('$org_name','$no_of_emp','$phone','$address','$city','$state','$zip_code')";
 if(mysqli_query($con,$query))
 {
     echo"details inserted sucessfully";

 }
 else
 {
     echo "failed to insert";
}
}
?>