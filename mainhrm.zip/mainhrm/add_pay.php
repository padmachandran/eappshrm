<!DOCTYPE html>
<html>

<body>

<form action="add_pay.php" method="POST">
name<input type="text" name="name"><br>
currency<input type="text" name="currency"><br>
min_sal<input type="text" name="min_sal"><br>
max_sal<input type="text" name="max_sal"><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$name=$_POST['name'];
$currency=$_POST['currency'];
$min_sal=$_POST['min_sal'];
$max_sal=$_POST['max_sal'];

$query = "INSERT INTO add_pay(name,currency,min_sal,max_sal)
  VALUES('$name','$currency','$min_sal','$max_sal')";
 if(mysqli_query($con,$query))
 {
     echo"details inserted sucessfully";

 }
 else
 {
     echo "failed to insert";
}
}
?>