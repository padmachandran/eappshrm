<!DOCTYPE html>
<html>

<body>

<form action="addemployee.php" method="POST">
id<input type="text" name="emp_id"  required><br>
Fname<input type="text" name="first_name"  required><br>
Mname<input type="text" name="middle_name"><br>
Lname<input type="text" name="last_name" required><br>
u_role<select name="u_role">
<option value="admin">admin</option>
<option value="ess">ess</option>
</select><br>
username<input type="text" name="username"  required><br>
password<input type="password" name="password"  required><br>
conpass<input type="password" name="con_pass" required><br>
status<input type="text" name="status" required><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
  $first_name=$_POST['emp_id'];
$first_name=$_POST['first_name'];
$middle_name=$_POST['middle_name'];
$last_name=$_POST['last_name'];
$u_role=$_POST['u_role'];
$username=$_POST['username'];
$password=$_POST['password'];
$con_pass=$_POST['con_pass'];
$status=$_POST['status'];

if($password!=$con_pass)
{
echo"invalid";
}
else
{
	mysqli_select_db($con,'add_employees');
  $res="INSERT INTO add_employees(emp_id,first_name,middle_name,last_name,u_role,username,password,con_pass,status)VALUES('$emp_id','$first_name','$middle_name','$last_name','$u_role','$username','$password','$con_pass','$status')";
  $result=mysqli_query($con,$res);
  //$last_id = mysqli_insert_id($con);
  echo "sucess";
}
}
?>