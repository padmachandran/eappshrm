<!DOCTYPE html>
<html>

<body>

<form action="adduserrole.php" method="POST">
unamae<input type="text" name="username"><br>
u_role<select name="user_role">
<option value="admin">admin</option>
<option value="ess">ess</option>
</select><br>
emp-name<input type="text" name="emp_name"><br>
status<select name="status">
<option value="enabled">enabled</option>
<option value="disabled">disabled</option>
</select><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$username=$_POST['username'];
$user_role=$_POST['user_role'];
$emp_name=$_POST['emp_name'];
$status=$_POST['status'];
  $query = "INSERT INTO add_users(username,user_role,emp_name,status)
  VALUES('$username','$user_role','$emp_name','$status')";
 if(mysqli_query($con,$query))
 {
     echo"details inserted sucessfully";

 }
 else
 {
     echo "failed to apply";
}
}
?>