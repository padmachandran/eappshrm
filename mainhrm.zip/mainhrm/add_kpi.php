<!DOCTYPE html>
<html>

<body>

<form action="add_kpi.php" method="POST">
kpi<input type="text" name="key_performance"><br>
tit<input type="text" name="job_title"><br>
min<input type="text" name="min_rate"><br>
max<input type="text" name="max_rate"><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$key_performance=$_POST['key_performance'];
$job_title=$_POST['job_title'];
$min_rate=$_POST['min_rate'];
$max_rate=$_POST['max_rate'];
  $query = "INSERT INTO add_kpi(key_performance,job_title,min_rate,max_rate)
  VALUES('$key_performance','$job_title','$min_rate','$max_rate')";
 if(mysqli_query($con,$query))
 {
     echo"details inserted sucessfully";

 }
 else
 {
     echo "failed to apply";
}
}
?>