﻿<?php
require('dbconn.php');
session_start();

echo $_SESSION['username']; 
?>

<div class="na" >
<ul>
<li><a href="addemployee.php">add employee</li>
<li><a href="addemplist.php">add emp list</li>
<li><a href="#">add leave</li>
<li><a href="#">add category</li>
<li><a href="logout.php">logout</li>
</ul>
</div>
