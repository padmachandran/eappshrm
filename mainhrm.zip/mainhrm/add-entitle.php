<!DOCTYPE html>
<html>

<body>

<form action="add-entitle.php" method="POST">
namae<input type="text" name="emp_name"><br>
lo<input type="text" name="location"><br>
sub<input type="text" name="sub_unit"><br>
ltype<input type="text" name="leave_type"><br>
lp<input type="date" name="leave_period"><br>
en<input type="text" name="entitle"><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$emp_name=$_POST['emp_name'];
$location=$_POST['location'];
$sub_unit=$_POST['sub_unit'];
$leave_type=$_POST['leave_type'];
$leave_period=$_POST['leave_period'];
$entitle=$_POST['entitle'];
  $query = "INSERT INTO add_entitlement(emp_name,location,sub_unit,leave_type,leave_period,entitle)
  VALUES('$emp_name','$location','$sub_unit','$leave_type','$leave_period','$entitle')";
 if(mysqli_query($con,$query))
 {
     echo"details inserted sucessfully";

 }
 else
 {
     echo "failed to apply";
}
}
?>