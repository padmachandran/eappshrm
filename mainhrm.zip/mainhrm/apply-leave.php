<!DOCTYPE html>
<html>

<body>

<form action="apply-leave.php" method="POST">
leave_type<select name="leave_type">
<option value="casual">casual</option>
<option value="sick">sick</option>
</select><br>
leave_balance<input name="leave_balance" >--<br>
fdate<input type="date" name="from_date"><br>
tdate<input type="date" name="to_date"><br>
tdate<input type="text" name="lev_comments"><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$leave_type=$_POST['leave_type'];
$leave_balance=$_POST['leave_balance'];
$from_date=$_POST['from_date'];
$to_date=$_POST['to_date'];
$lev_comments=$_POST['lev_comments'];

  $query = "INSERT INTO apply_leave(leave_type,leave_balance,from_date,to_date,lev_comments)
  VALUES('$leave_type','$leave_balance','$from_date','$to_date','$lev_comments')";
 if(mysqli_query($con,$query))
 {
     echo"leave applied successfully";

 }
 else
 {
     echo "failed to apply";
}
}
?>