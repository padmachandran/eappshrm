<!DOCTYPE html>
<html>

<body>

<form action="emp_qualification.php" method="POST">
com<input type="text" name="company" ><br>
job_title<input type="text" name="job_title"><br>
job_from<input type="date" name="job_from"><br>
job_to<input type="date" name="job_to"><br>
jobcom<input type="text" name="job_comment"><br>
level<select name="level">
<option value="mab">mba</option>
<option value="mca">mca</option>
</select><br>
ins<input type="text" name="institute"><br>
yr<input type="date" name="year"><br>
gpa<input type="text" name="gpa"><br>
st-date<input type="date" name="start_date"><br>
end_date<input type="date" name="end_date"><br>
skill<input type="text" name="skill" ><br>
skill_exp<input type="text" name="skill_exp" ><br>
skcom<input type="text" name="skill_comments" ><br>
lan<input type="text" name="language" ><br>
flu<input type="text" name="fluency" ><br>
com<input type="text" name="competency" ><br>
lan-com<input type="text" name="lan_comments" ><br>
<input type="submit" name="submit">
</form>
</body>
</html>

<?php
session_start();
require('dbconn.php');
if(isset($_POST['submit']))
{
$company=$_POST['company'];
$job_title=$_POST['job_title'];
$job_from=$_POST['job_from'];
$job_to=$_POST['job_to'];
$job_comment=$_POST['job_comment'];
$level=$_POST['level'];
$institute=$_POST['institute'];
$year=$_POST['year'];
$gpa=$_POST['gpa'];
$start_date=$_POST['start_date'];
$end_date=$_POST['end_date'];
$skill=$_POST['skill'];
$skill_exp=$_POST['skill_exp'];
$skill_comments=$_POST['skill_comments'];
$language=$_POST['language'];
$fluency=$_POST['fluency'];
$competency=$_POST['competency'];
$lan_comments=$_POST['lan_comments'];

  $query = "INSERT INTO qualifications(company,job_title,job_from,job_to,job_comment,level,institute,year,gpa,start_date,end_date,
  skill,skill_exp,skill_comments,language,fluency,competency,lan_comments)
  VALUES('$company','$job_title','$job_from','$job_to','$job_comment','$level','$institute','$year','$gpa','$start_date','$end_date',
  '$skill','$skill_exp','$skill_comments','$language','$fluency','$competency','$lan_comments')";
 if(mysqli_query($con,$query))
 {
     echo"details inserted successfully";

 }
 else
 {
     echo "failed to insert";
}
}
?>